// var express = require('express');
// var router = express.Router();
// var mealController = require('./workoutsController');
// console.clear()



// router.post('/add-workouts', mealController.addMeals);

// router.get('/view-meals/:id', mealController.viewMeals)

// // router.post('/login', userController.login);

// module.exports = router;
